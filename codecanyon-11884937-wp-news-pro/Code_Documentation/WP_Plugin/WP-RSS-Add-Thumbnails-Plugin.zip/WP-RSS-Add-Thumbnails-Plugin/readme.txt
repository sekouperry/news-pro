=== WP RSS Add Thumbnails ===
Tags: rss, rss2, image, feed, post, news

Include images in your Wordpress RSS feed for Codecanyon WPNews App.

== Description ==

Simple plugin that allows to include the thumbnail image of your post in your Wordpress RSS & RSS2 feeds.
You can select the  size of the images on the admin panel.

== Installation ==

1. Upload WP RSS Add Thumbnails folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Settings/WP RSS Add Thumbnails and select the image size (Medium, Full) and feed type (RSS, RSS2).






